<?php
$key = $_GET['key'];
$file = 'dat/' . implode('/', str_split($key)) . '/dat';
if (is_file($file)) {
	$url = file_get_contents($file);
	header('HTTP/1.1 301 Moved Permanently');
	header('Location: ' . $url);
} else {
	header('HTTP/1.1 404 File Not Found');
}
?>
