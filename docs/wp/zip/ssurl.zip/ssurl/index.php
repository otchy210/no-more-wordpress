<?php
define('OWN', 'http://otchy.net/');
define('TARGET', 'http://www.otchy.net/');
define('LEN', 3);
define('CHARS', '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz');
define('EXP', strlen(CHARS));
function shorten() {
	$url = $_GET['url'];
	$pos = strpos($url, TARGET);
	if ($pos !== 0) {
		global $message;
		$message = 'Input URL for "' . TARGET . '".';
		return FALSE;
	}
	$dir = nextDir();
	$file = $dir . '/dat';
	$fp = fopen($file, 'w');
	fputs($fp, $url);
	fclose($fp);
	$chars = explode('/', $dir);
	array_shift($chars);
	array_shift($chars);
	return OWN . implode($chars);
}
function nextDir() {
	$dir = 'dat';
	$id = 0;
	for ($i=LEN-1; $i>=0; $i--) {
		$num = currentNum($dir);
		$id += $num * pow(EXP, $i);
		$dir .= '/' . substr(CHARS, $num, 1);
	}
	$id++;
	$dir = '';
	for ($i=0; $i<LEN; $i++) {
		$num = $id % EXP;
		$dir = '/' . substr(CHARS, $num, 1) . $dir;
		$id = intval($id / EXP);
	}
	$dir = 'dat' . $dir;
	$dirs = explode('/', $dir);
	$dir = '.';
	foreach ($dirs as $d) {
		$dir .= '/' . $d;
		if (!is_dir($dir)) {
			mkdir($dir);
		}
	}
	return $dir;
}
function currentNum($dir) {
	$files = scandir($dir);
	$char = $files[count($files)-1];
	if ($char == '..') return 0;
	return strpos(CHARS, $char);
}
$url = FALSE;
if ($_GET['submit'] == 'shorten' || strlen($_GET['callback']) > 0) {
	$url = shorten();
	$callback = $_GET['callback'];
	if (strlen($callback) > 0) {
		$json = '';
		if ($url === FALSE) {
			$json = '{errmsg:' . "'" . $message . "'" . '}';
		} else {
			$json = '{url:"' . $url . '"}';
		}
		echo $callback . '(' . $json . ');';
		exit;
	}
}
?>
<html>
<head>
</head>
<body>
<div style="color:red;"><?php echo $message ?></div>
<form method="GET">
URL<input name="url" value="<?php echo htmlspecialchars($_GET['url']) ?>" /><input type="submit" name="submit" value="shorten" />
</form>
<?php if ($url !== FALSE) { ?>
<div style="color:green;">
Success shorten: <?php echo htmlspecialchars($_GET['url']) ?> to <a href="<?php echo $url ?>" target="_blank"><?php echo $url ?></a>
</div>
<?php } ?>
<div>
Bookmarklet:<a href="javascript:(function(w,d,s){if(!w.ssurl){w.ssurl=function(o){if(o.errmsg){alert(o.errmsg);}else{prompt('Shorten!',o.url);}}}s=d.createElement('script');s.src='<?php echo OWN ?>?url='+location.href+'&callback=ssurl';d.getElementsByTagName('head')[0].appendChild(s);})(window,document);">Shorten!</a>
</div>
</body>
</html>